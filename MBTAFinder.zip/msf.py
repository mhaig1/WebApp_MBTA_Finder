import urllib.request
import json
import sys

def get_address():
    location = str(input('Enter Location: '))
    location = location.replace(' ', '%20')
    return location

def get_geo_data():
    addy = get_address()
    mqkey = 'uPK2UZtSTAyMfgXARKZlXx7PZN9kWhUk'
    url = f'http://www.mapquestapi.com/geocoding/v1/address?key={mqkey}&location={addy}'
    f = urllib.request.urlopen(url)
    responsetext = f.read().decode('utf-8')
    responsedata = json.loads(responsetext)
    return responsedata

def get_coordinates():
    data = get_geo_data()
    n = len(data['results'][0]['locations'])
    c = []
    i = 0
    state = 'MA'
    for i in range(0,n):
        if data['results'][0]['locations'][i]['adminArea3'] == state:
            lat = data['results'][0]['locations'][i]['displayLatLng']['lat']
            c.append(lat)
            lon = data['results'][0]['locations'][i]['displayLatLng']['lng']
            c.append(lon)
            return c
        else:
            i += 1
    sys.exit('Location inputted was not valid. Please enter the address for better results.')

def get_mbta_data():
    l = get_coordinates()
    lat = l[0]
    lon = l[1]
    url = f'https://api-v3.mbta.com/stops?filter[latitude]={lat}&filter[longitude]={lon}'
    f = urllib.request.urlopen(url)
    responsetext = f.read().decode('utf-8')
    responsedata = json.loads(responsetext)
    return responsedata


def get_closest():
    data = get_mbta_data()
    h = data['data'][0]['attributes']['wheelchair_boarding']
    if h == 0:
        a = 'Not Sure If Handicap Accessible'
    elif h == 1:
        a = 'Handicap Accessible'
    elif h == 2:
        a = 'Not Handicap Accessible'
    d = str(data['data'][0]['attributes']['description'])
    f = d + ': ' + a
    return f

if __name__ == '__main__':
    get_closest()
