import urllib.request
import json
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/', methods=['POST', 'GET'])
def home():

    if request.method == 'POST':
        return render_template('index.html')
    else:
        return render_template('index.html')

@app.route('/stops', methods=['POST', 'GET'])
def stops():
    location = request.args.get('location')
    stops = merged_function(location)
    return render_template('stops.html', stops=stops)

def merged_function(a):
    location = a
    location = location.replace(' ', '%20')
    mqkey = 'uPK2UZtSTAyMfgXARKZlXx7PZN9kWhUk'
    url = f'http://www.mapquestapi.com/geocoding/v1/address?key={mqkey}&location={location}'
    f = urllib.request.urlopen(url)
    responsetext = f.read().decode('utf-8')
    data = json.loads(responsetext)
    n = len(data['results'][0]['locations'])
    c = []
    i = 0
    state = 'MA'
    lat = 0
    lon = 0
    for i in range(0,n):
        if data['results'][0]['locations'][i]['adminArea3'] == state:
            lat = data['results'][0]['locations'][i]['displayLatLng']['lat']
            c.append(lat)
            lon = data['results'][0]['locations'][i]['displayLatLng']['lng']
            c.append(lon)
            break
        else:
            i += 1
    if lat == 0:
        return('Location not found. Try entering address.')
    lat = c[0]
    lon = c[1]
    url = f'https://api-v3.mbta.com/stops?filter[latitude]={lat}&filter[longitude]={lon}'
    f = urllib.request.urlopen(url)
    responsetext = f.read().decode('utf-8')
    data = json.loads(responsetext)
    h = data['data'][0]['attributes']['wheelchair_boarding']
    if h == 0:
        a = 'Not Sure If Handicap Accessible'
    elif h == 1:
        a = 'Handicap Accessible'
    elif h == 2:
        a = 'Not Handicap Accessible'
    na = str(data['data'][0]['attributes']['name'])
    f = na + ': ' + a
    return f

if __name__ == '__main__':
    app.run(debug=True)
